import React from "react";
import styled from "styled-components";
import PropTypes from "prop-types";
import Title from "../../components/title/index";
import NmsBox from "../../components/boxes/NmsBox";
import UpdownGroup from "../../components/updown/UpdownGroup";

const FlexWrapper = styled.div`
  display: flex;
`;

const LEFT1 = styled.div`
  display: inline-block;
  padding: 38px 13px 13px 13px;
  width: 885px;
  height: 270px;
`;
const RIGHT1 = styled.div`
  display: inline-block;
  padding: 38px 13px 13px 13px;
  width: 1023px;
  height: 270px;
`;
const LEFT2 = styled.div`
  display: inline-block;
  position: absolute;
  padding: 0px 13px 13px 13px;
  width: 885px;
  height: 154px;
  top: 269px;
  left: 0px;
`;
const RIGHT2 = styled.div`
  display: inline-block;
  position: absolute;
  padding: 0px 13px 13px 13px;
  width: 1023px;
  height: 154px;
  top: 269px;
  left: 885px;
`;
const LineStatus = ({ style }) => {
  const nonhyeon = [
    {
      line1:window.NMS_NONHYEON_CONFIG.nonhyeon.line1
    },
    {
      line2:window.NMS_NONHYEON_CONFIG.nonhyeon.line2
    }
  ];
  const kimpo = [
    {
      line1:window.NMS_KIMPO_CONFIG.kimpo.line1
    },
    {
      line2:window.NMS_KIMPO_CONFIG.kimpo.line2
    }
  ]
  const LeftTitleStyle = {
    left: "13px",
    top: "12px",
  };
  const RightTitleStyle = {
    left: "898px",
    top: "12px",
  };
  const BOX = {
    left1Style: {
      width: "273px",
    },
    right1Style: {
      width: "320px",
    },
    left2Style: {
      width: "841px",
    },
    right2Style: {
      width: "983px",
    },
  };
  
  const FIRSTCANTERNAME = [];
  for (var i = 0; i < nonhyeon.line1.length; i++) {
    FIRSTCANTERNAME.push({ NAME: `${firstLine[i].centerName}`, STATUS: 1 });
  }
  for (var i = 0; i < kimpo.line1.length; i++) {
    FIRSTCANTERNAME.push({ NAME: `${firstLine[i].centerName}`, STATUS: 1 });
  }
  console.log(FIRSTCANTERNAME);
  debugger;

  const SECONDCANTERNAME = [];
  for (var i = 0; i < nonhyeon.line2.length; i++) {
    SECONDCANTERNAME.push({ NAME: `${firstLine[i].centerName}`, STATUS: 1 });
  }
  for (var i = 0; i < nonhyeon.line2.length; i++) {
    SECONDCANTERNAME.push({ NAME: `${firstLine[i].centerName}`, STATUS: 1 });
  }


  const Nonhyeon_DataArr = [];
  for (var j = 0; j < firstLine.length; j++) {
    for (var k = 0; k < firstLine[j].groups.length; k++) {
      Nonhyeon_DataArr.push({
        id: k,
        status: 0,
        name: `${firstLine[j].groups[k].groupName}`,
        up_cnt: 1,
        down_cnt: 0,
      });
    }
  }
  const Nonhyeon_DataArr = [];
  for (var j = 0; j < firstLine.length; j++) {
    for (var k = 0; k < firstLine[j].groups.length; k++) {
      Nonhyeon_DataArr.push({
        id: k,
        status: 0,
        name: `${firstLine[j].groups[k].groupName}`,
        up_cnt: 1,
        down_cnt: 0,
      });
    }
  }
  FIRSTCANTERNAME[0].LeftColumnDataArr = [
    Nonhyeon_DataArr[0],
    Nonhyeon_DataArr[1],
  ];
  FIRSTCANTERNAME[1].LeftColumnDataArr = [
    Nonhyeon_DataArr[2],
    Nonhyeon_DataArr[3],
  ];
  FIRSTCANTERNAME[2].columnDataArr = [Nonhyeon_DataArr[4], Nonhyeon_DataArr[5]];

  const columnDataArr = [
    {
      id: 1,
      status: 0,
      name: "장비명01 (CISCO백본)",
      up_cnt: 1,
      down_cnt: 15,
    },
    {
      id: 2,
      status: 3,
      name: "장비명01 (CISCO백본)",
      up_cnt: 1,
      down_cnt: 0,
    },
  ];
  const rowDataArr = [
    {
      id: 1,
      status: 0,
      name: "장비명01 (CISCO백본)",
      up_cnt: 1,
      down_cnt: 15,
    },
    {
      id: 2,
      status: 3,
      name: "장비명01 (CISCO백본)",
      up_cnt: 1,
      down_cnt: 0,
    },
    {
      id: 3,
      status: 1,
      name: "장비명01 (CISCO백본)",
      up_cnt: 1,
      down_cnt: 15,
    },
    {
      id: 4,
      status: 3,
      name: "장비명01 (CISCO백본)",
      up_cnt: 1,
      down_cnt: 0,
    },
  ];

  return (
    <section className="p-abs" style={style}>
      <Title style={LeftTitleStyle} text={"회선상태"} />
      <Title style={RightTitleStyle} text={"회선상태"} />
      <LEFT1>
        {FIRSTCANTERNAME.map((data, index) => {
          const updown = data.columnDataArr;
          return (
            <NmsBox key={String(index)} data={data} style={BOX.left1Style}>
              {updown.map((data) => (
                <UpdownGroup key={data.id} data={data} display="column" />
              ))}
            </NmsBox>
          );
        })}
      </LEFT1>
      <RIGHT1>
        {FIRSTCANTERNAME.map((data, index) => {
          return (
            <NmsBox key={String(index)} data={data} style={BOX.right1Style}>
              {columnDataArr.map((data) => (
                <UpdownGroup key={data.id} data={data} display="column" />
              ))}
            </NmsBox>
          );
        })}
      </RIGHT1>
      <LEFT2>
        {SECONDCANTERNAME.map((data, index) => {
          return (
            <NmsBox key={String(index)} data={data} style={BOX.left2Style}>
              <FlexWrapper style={BOX.left2Style}>
                {rowDataArr.map((data) => (
                  <UpdownGroup key={data.id} data={data} display="row" />
                ))}
              </FlexWrapper>
            </NmsBox>
          );
        })}
      </LEFT2>
      <RIGHT2>
        {SECONDCANTERNAME.map((data, index) => {
          return (
            <NmsBox key={String(index)} data={data} style={BOX.right2Style}>
              <FlexWrapper style={BOX.right2Style}>
                {rowDataArr.map((data) => (
                  <UpdownGroup key={data.id} data={data} display="row" />
                ))}
              </FlexWrapper>
            </NmsBox>
          );
        })}
      </RIGHT2>
    </section>
  );
};

LineStatus.propTypes = {
  style: PropTypes.object,
};
export default LineStatus;
