import color from "./color";
import common from "./common";

const theme = {
  color,
  common,
};

export default theme;
